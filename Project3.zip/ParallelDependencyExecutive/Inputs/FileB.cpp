using namespace B;

int main(){
	Bstruct bs;
	A b;
	b.methodA();
	bs.methodB();
	return 0;	
}