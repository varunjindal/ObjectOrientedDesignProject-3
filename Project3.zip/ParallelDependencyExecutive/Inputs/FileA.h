/*
	Simple file with one class in global namespace
*/
class A {
	A();
	~A();
	void methodA();
};